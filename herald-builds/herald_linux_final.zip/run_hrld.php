<?php

shell_exec("sudo nohup python3 herald.py > herald.log &");

?>