#!/usr/bin/env python

import sys
import os
import requests
import csv
from datetime import date


##Upload B92
os.system(
    "wget https://gatos-jabra-buster.azurewebsites.net/api/RssToCsv?url=http://www.b92.net/info/rss/novo.xml -O r_output_b92.csv")
sys.stdout.write("Uploading B92...\n")

post_url = 'https://api.airtable.com/v0/appqELtvF24gYtTyN/B92'
post_headers = {
    'Authorization': 'Bearer keygdLVLXS2jxQEqt',
    'Content-Type': 'application/json'
}

f = open('r_output_b92.csv')
csv_f = csv.reader(f)

for row in csv_f:
    pubDate = row[3]
    title = row[0]
    link = row[1]

    data = {
        "fields": {
            "pubDate": pubDate,
            "title": title,
            "link": link
        }
    }

    print(post_url)
    print(data)

    post_airtable_request = requests.post(post_url, headers=post_headers, json=data)
    print(post_airtable_request.status_code)

##Upload B92
os.system(
    "wget https://gatos-jabra-buster.azurewebsites.net/api/RssToCsv?url=https://balkaninsight.com/feed/ -O r_output_bi.csv")
sys.stdout.write("Uploading BalkanInsight...\n")

post_url = 'https://api.airtable.com/v0/appqELtvF24gYtTyN/BalkanInsight'
post_headers = {
    'Authorization': 'Bearer keygdLVLXS2jxQEqt',
    'Content-Type': 'application/json'
}

f = open('r_output_bi.csv')
csv_f = csv.reader(f)

for row in csv_f:
    pubDate = row[3]
    title = row[0]
    link = row[1]

    data = {
        "fields": {
            "pubDate": pubDate,
            "title": title,
            "link": link
        }
    }

    print(post_url)
    print(data)

    post_airtable_request = requests.post(post_url, headers=post_headers, json=data)
    print(post_airtable_request.status_code)

##Sanitize
sys.stdout.write("Function complete.\n")
os.remove('r_output_is.csv')
os.remove('r_output_bi.csv')
os.remove('r_output_b92.csv')
today = date.today()
print("Timeprint:", today)
