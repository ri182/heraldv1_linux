#! /bin/bash
while sleep 8000
do
	sh herald.sh
done

